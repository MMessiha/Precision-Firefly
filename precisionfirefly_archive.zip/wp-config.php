<?php
/** Enable W3 Total Cache */
define('WP_CACHE', true); // Added by W3 Total Cache

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'precision_firefly123757140318' );

/** MySQL database username */
define( 'DB_USER', '561_media' );

/** MySQL database password */
define( 'DB_PASSWORD', '561_media' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '&Df7E`J</4oHjZChR!rRnw6AOPO_TAaMgB &jB3:s;?z4w&>#f@.T!-t,Fl(GDhH' );
define( 'SECURE_AUTH_KEY',  'fU5t7`6)f&|j{2c-:<L&a+Ck@RahoSuR)4Gq =G9(+<=(S=|RK3H03DiQFOBq%m5' );
define( 'LOGGED_IN_KEY',    'c  1:m},y]Of.$B+Siu{^u%|DPpLx1Gw2=lP7=1FJyN?Nn(#!48`RP+i2E-^8(t=' );
define( 'NONCE_KEY',        'J-7U2/.zPFtDfYBeYk~FQwDv|7o.i6&+th YKJ$~f<,4}t%u#dz@s.*JIjz>H9KF' );
define( 'AUTH_SALT',        'U0+jWDCbq44_|IrPffn)M>*en_d9F=,gmb)&rIrT;P?.{o=7l;CW&gle[wDyJCxd' );
define( 'SECURE_AUTH_SALT', '|$HYeC?KM _4.* CJ_m)jYH-5o|x^CiO@1Lmoxvx#yOjZF}<z>5R)_Q$TW}{DJ_8' );
define( 'LOGGED_IN_SALT',   '(;[Mh|XwbXZv6BS8LKy;@8k,k{&$H{-n82eY0w!7?Awf:JXC,l@Oc|N6<RJ;&45S' );
define( 'NONCE_SALT',       ']wR~_W=d$kYR%QNs!*bS}2?&eCB1ZKqt+^&Oyf_i,XJBCSqg>QK6E!qjVEJ.z{)a' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
define('WP_DEBUG',false);
define('FS_METHOD','direct');
